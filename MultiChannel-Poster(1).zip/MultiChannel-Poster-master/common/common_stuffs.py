from datetime import timedelta
from telegram import Bot, ParseMode, InlineKeyboardButton, InlineKeyboardMarkup, Message
from telegram.error import RetryAfter, Unauthorized
from telegram.ext import messagequeue as mq
from time import sleep, time

from const import TG


class MQBot(Bot):
	def __init__(self, is_queued_def = True, mqueue = None, *args, **kwargs):
		super(MQBot, self).__init__(*args, **kwargs)
		self._is_messages_queued_default = is_queued_def
		self._msg_queue = mqueue or mq.MessageQueue()
	
	@mq.queuedmessage
	def send_message(self, *args, **kwargs):
		try:
			return super(MQBot, self).send_message(*args, **kwargs)
		except RetryAfter as sec:
			sleep(int(sec.retry_after))


def send_appr_msg(bot, to_chat_id, msg, parsing_mode = ParseMode.HTML, reply_mk = None, link_preview = True):
	if msg['photo']:
		caption = msg.caption_html if parsing_mode == ParseMode.HTML else msg.caption
		return bot.send_photo(chat_id = to_chat_id, caption = caption, photo = msg['photo'][-1]['file_id'],
		                      parse_mode = parsing_mode, reply_markup = reply_mk)
	elif msg['text']:
		text = msg.text_html if parsing_mode == ParseMode.HTML else msg.text
		return bot.send_message(text = text, chat_id = to_chat_id, parse_mode = parsing_mode,
		                        disable_web_page_preview = not link_preview, reply_markup = reply_mk)
	elif msg['sticker']:
		return bot.send_sticker(chat_id = to_chat_id, sticker = msg['sticker'])
	elif msg['document']:
		caption = msg.caption_html if parsing_mode == ParseMode.HTML else msg.caption
		return bot.send_document(chat_id = to_chat_id, document = msg['document'], caption = caption,
		                         parse_mode = parsing_mode, reply_markup = reply_mk)
	elif msg['animation']:
		return bot.send_animation(chat_id = to_chat_id, document = msg['animation'],
		                          parse_mode = parsing_mode, reply_markup = reply_mk)
	elif msg['video']:
		caption = msg.caption_html if parsing_mode == ParseMode.HTML else msg.caption
		return bot.send_video(chat_id = to_chat_id, video = msg['video']['file_id'], caption = caption,
		                      parse_mode = parsing_mode, reply_markup = reply_mk)
	elif msg['poll']:
		poll = msg['poll']
		is_anonymous = True if poll.is_anonymous else False
		allows_multiple_answers = True if poll.allows_multiple_answers else False
		answer_options = []
		for option in poll.options:
			answer_options.append(option.text)
		if poll.type == 'quiz':
			return bot.send_poll(type = poll.type,
			                     question = poll.question, options = answer_options,
			                     chat_id = to_chat_id, is_anonymous = is_anonymous,
			                     correct_option_id = poll.correct_option_id, explanation = poll.explanation,
			                     reply_markup = reply_mk)
		else:
			return bot.send_poll(type = poll.type,
			                     question = poll.question, options = answer_options,
			                     chat_id = to_chat_id, is_anonymous = is_anonymous,
			                     allows_multiple_answers = allows_multiple_answers, reply_markup = reply_mk)


def send_appr_msg_job(context):
	our_context = context.job.context  # msg, btn
	msg = our_context.message
	self_destruct = our_context.self_destruct
	btns = our_context.reply_markup
	chats = our_context.channels
	pin = our_context.pin
	success = failed = failed_pins = 0
	start_time = time()
	new_btn_mk = InlineKeyboardMarkup(btns) if btns else None
	errors = "Errors Occurred during broadcast,"
	sent_msgs = {}
	for chat in chats:
		try:
			sent_msg = send_appr_msg(context.bot, to_chat_id = chat, msg = msg,
			                         reply_mk = new_btn_mk, parsing_mode = 'HTML')
			if str(type(sent_msg)).endswith("Promise'>"):
				sent_msg = sent_msg.result()
			if self_destruct:
				context.job_queue.run_once(when = timedelta(minutes = self_destruct),
				                           callback = delete_job, context = (sent_msg, chat),
				                           name = f"Self-destruct-at-{self_destruct}")
			sent_msgs.update({chat: sent_msg.message_id})
			success += 1
		except RetryAfter as sec:
			sleep(int(sec.retry_after))
		except Exception as e:
			errors += f"\nChatID:{chat} - {e}"
			failed += 1
			sleep(0.1)
	if pin:
		for chat in sent_msgs:
			try:
				context.bot.pin_chat_message(chat_id = chat,
			                               message_id = sent_msgs[chat],
			                               timeout = 5)
			except RetryAfter as sec:
				sleep(int(sec.retry_after))
			except Exception as e:
				if failed_pins == 0:
					errors += "f\n\nFailed to pin messages.,"
				errors += f"\nChatID:{chat} - {e}"
				failed_pins += 1
				sleep(0.5)
		sleep(0.5)  # # cooldown period for pin
	sleep(0.5)  # # cooldown period
	to_send = f"<b><u>Broadcast Stats</u></b>" \
	          f"\n" \
	          f"\n\t👮🏼‍♀️ <b>Total Chats</b> : {len(chats)}" \
	          f"\n\t✅ <b>Success</b> : {success}" \
	          f"\n\t❌ <b>Failed</b> : {failed}" \
	          f"\n\t🕐 <b>Total time taken</b> : {round(time() - start_time, 2)} secs"
	for admin in TG.ADMINS:
		sent_msg = send_appr_msg(context.bot, to_chat_id = admin, msg = msg,
		              reply_mk = new_btn_mk, parsing_mode = 'HTML')
		if str(type(sent_msg)).endswith("Promise'>"):
			sent_msg = sent_msg.result()
		context.bot.send_message(text = to_send, chat_id = admin, parse_mode = 'HTML',
		                         reply_to_message_id = sent_msg.message_id)
	
		if failed:
			context.bot.send_message(text = errors, chat_id = admin, reply_to_message_id = sent_msg.message_id)


def delete_job(context):
	our_context = context.job.context
	try:
		our_context[0].delete()
	except Exception as e:
		error = f"Exception raised while self-destructing," \
		        f"\nCHATID : {our_context[1]}" \
		        f"\n{e}"
		for admin in TG.ADMINS:
			context.bot.send_message(text = error, chat_id = admin)

