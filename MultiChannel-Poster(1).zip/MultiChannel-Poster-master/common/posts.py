class Post:
	def __init__( self, message, channels, reply_markup = None,
	              link_preview = False, pin = False, self_destruct = False):
		self.message = message
		self.channels = channels
		self.reply_markup = reply_markup
		self.link_preview = link_preview
		self.pin = pin
		self.self_destruct = self_destruct
		
	def __str__(self):
		return f"""📌 <b>Pin</b>: {self.pin}
🔗 <b>Link Preview</b>: {self.link_preview}
💣 <b>Self-Destruct</b>: {self.self_destruct} (mins)"""
