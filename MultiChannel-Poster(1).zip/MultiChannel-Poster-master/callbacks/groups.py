from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext

from backend import Groups as GroupsDB


class Groups:
	@staticmethod
	def get_name(update: Update, context: CallbackContext):
		update.effective_message.reply_text("Send the name of the group,")
		return 1
	
	@staticmethod
	def create(update: Update, context: CallbackContext):
		GroupsDB.insert(update.effective_message.text_html)
		update.effective_message.reply_text("Group has been inserted successfully!")
		return -1
	
	@staticmethod
	def list(update: Update, context: CallbackContext):
		grps = GroupsDB.list()
		try:
			to_send = "Your Groups:"
			btns = []
			for grp in grps:
				btns.append([InlineKeyboardButton(grp['name'], callback_data = f"grp_{grp['_id']}")])
			update.effective_message.reply_text(to_send, reply_markup = InlineKeyboardMarkup(btns))
		except Exception as e:
			update.effective_message.reply_text(f"{e}")
	
	@staticmethod
	def get(update: Update, context: CallbackContext):
		data = update.callback_query.data
		update.callback_query.answer("Fetching group details..please wait.,")
		grpid = data.split('_')[-1]
		grpinfo = GroupsDB.get(grpid)
		if grpinfo:
			btns = []
			err = ""
			for chnl in grpinfo['channels']:
				try:
					chnlinfo = context.bot.get_chat(chat_id = chnl)['title']
					btns.append([InlineKeyboardButton(chnlinfo, callback_data = f"rm_chnl_{grpid}_{chnl}")])
				except Exception as e:
					err += f"\n{chnl} = {e}"
			if btns:
				update.effective_message.reply_text(f"Details of Group ({grpinfo['name']}):"
				                                    f"\n❌ To remove a channel, tap on the below button",
				                                    reply_markup = InlineKeyboardMarkup(btns))
			else:
				update.effective_message.reply_text(f"Details of Group ({grpinfo['name']}):"
				                                    f"\nNo channels found", )
			
			if err:
				update.effective_message.reply_text(err)
				
	@staticmethod
	def remove(update: Update, context: CallbackContext):
		try:
			grpname = context.args[0]
			GroupsDB.remove(grpname)
			update.effective_message.reply_text("Group removed successfully!")
		except IndexError:
			update.effective_message.reply_text("⚠ No Group name entered"
			                                    "\nFormat: /remove_group grpname-here")
	