from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import CallbackContext

from backend import Groups as GroupsDB


class Channels:
	@staticmethod
	def add(update: Update, context: CallbackContext):
		update.effective_message.reply_text("Forward me a message from the channel")
		return 1
	
	@staticmethod
	def add_2(update: Update, context: CallbackContext):
		channlid = update.message.forward_from_chat.id
		grps = GroupsDB.list()
		btns = []
		for grp in grps:
			btns.append([InlineKeyboardButton(grp['name'], callback_data = f"select_{grp['_id']}_{channlid}")])
		update.effective_message.reply_text("Select a group in which this channel should be added",
		                                    reply_markup = InlineKeyboardMarkup(btns))
		return 2
	
	@staticmethod
	def add_3(update: Update, context: CallbackContext):
		try: update.callback_query.edit_message_reply_markup(reply_markup = None)
		except: pass
		_, grpid, chnlid = update.callback_query.data.split('_')
		GroupsDB.add_channel(channelid = chnlid, grpid = grpid)
		update.effective_message.reply_text("Channel has been added successfully!")
		return -1
	
	@staticmethod
	def remove(update: Update, context: CallbackContext):
		update.callback_query.answer("Removing the channel...")
		try: update.callback_query.edit_message_reply_markup(reply_markup = None)
		except: pass
		data = update.callback_query.data
		_, _, grpid, chnlid = data.split('_')
		GroupsDB.remove_channel(channelid = chnlid, grpid = grpid)
		update.effective_message.reply_text("Successfully removed the channel from the group",
		                                    reply_markup = InlineKeyboardMarkup([
			                                    [InlineKeyboardButton("Get this group details",
			                                                          callback_data = f"grp_{grpid}")]]))
		
	