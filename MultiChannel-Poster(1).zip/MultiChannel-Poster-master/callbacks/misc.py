from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext


class Misc:
	@staticmethod
	def help(update: Update, context: CallbackContext):
		try:  # Just In case, if the message doesn't contain replymk or callback_query is not present
			update.callback_query.edit_message_reply_markup(reply_markup = None)
		except: pass
		try:
			context.user_data.clear()
		except: pass
		update.effective_message.reply_text("""
		<u><b>HELP</b></u>
		1) Add new group,
			\ti. Send /add_group
		 \tii. Send the name of the group
		2) /list = Lists the groups
		3) /add_channel = Add a channel
		4) Remove a channel from a group,
			\ti. Send /list and Select the group
		 \tii. Now, it will show list of channels connected
		\tiii. Select a channel to remove from the group
		5) Remove a group,
			/remove_group grpname-here
		6) /broadcast = Broadcast a message to group
		""", parse_mode = "HTML",
	reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton('Contact the developer 🤖',
	                                                           url = 'https://t.me/ys0seri0us')]]))
		return -1