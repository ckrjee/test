from telegram import InlineKeyboardMarkup, InlineKeyboardButton, Update
from telegram.ext import CallbackContext

from backend import Groups
from callbacks.misc import Misc
from common import send_appr_msg, send_appr_msg_job, Post
from const import TG, States, Users


class Posts:
	@staticmethod
	def get_group(update: Update, context: CallbackContext):
		btns = []
		for grp in Groups.list():
			btns.append([InlineKeyboardButton(grp['name'], callback_data = f"brd_grp_{grp['_id']}")])
		if not btns:
			update.effective_message.reply_text("OOPS!! You didn't create any groups yet")
			return -1
		btns.append([InlineKeyboardButton("Back", callback_data = 'back')])
		update.effective_message.reply_text("Select the group you want the message to send,",
		                                    reply_markup = InlineKeyboardMarkup(btns))
		
		return States.GROUP
	
	@staticmethod
	def broadcast_strt(update, context):
		if update.effective_user.id not in TG.ADMINS:
			return States.END
		try:  # Just In case, if the message doesn't contain replymk or callback_query is not present
			update.callback_query.edit_message_reply_markup(reply_markup = None)
		except: pass
		data = update.callback_query.data
		grpid = data.split('_')[-1]
		context.user_data['chnls'] = Groups.get(grpid)['channels']
		update.effective_message.reply_text("Send me the message you wanna broadcast,")
		return States.START
	
	@staticmethod
	def add_posts(update, context):
		# context.user_data['msg'] = update.message
		plus_btn_markup = InlineKeyboardMarkup([[InlineKeyboardButton('➕ Add Buttons', callback_data = 'buttons')],
		                                        [InlineKeyboardButton('✔ Finish', callback_data = 'finish')]])
		context.user_data['msg'] = send_appr_msg(bot = context.bot, to_chat_id = update.message.chat_id,
		                                        parsing_mode = "HTML", reply_mk = plus_btn_markup, msg = update.message)
		if str(type(context.user_data['msg'])).endswith("Promise'>"):
			context.user_data['msg'] = context.user_data['msg'].result()
		return States.BTNS
	
	@staticmethod
	def inline_handler_for_btn_creation(update, context):
		query = update.callback_query
		data = query.data
		try:  # Just In case, if the message doesn't contain replymk or callback_query is not present
			update.callback_query.edit_message_reply_markup(reply_markup = None)
		except: pass
		if data == 'finish':
			update.effective_message.delete()
			return Posts.store_msg(update, context)
		elif data == 'buttons':
			update.effective_message.reply_text("""
			Send me a list of URL buttons for the message. Please use this format:
Button text 1 - http://www.example.com/ | Button text 2 - http://www.example2.com/
Button text 3 - http://www.example3.com/""")
			return States.TXT
		elif data == 'back':
			return Posts.get_group(update, context)
		
	@staticmethod
	def get_text(update, context):
		user_input = update.effective_message.text
		final_btns = []
		try:
			for row in user_input.split("\n"):
				temp_btn = []
				for button in row.split("|"):
					if len(button.split(" - ")) == 2 :
						text, url = button.split(" - ")
						temp_btn.append(InlineKeyboardButton(text, url = url))
					else:
						raise Exception("A hypen is used to separate name and url, also include a space around them")
				final_btns.append(temp_btn)
			context.user_data['btns'] = final_btns.copy()
			final_btns.append([InlineKeyboardButton("🔙 Back", callback_data = 'back'),
			                   InlineKeyboardButton("✅ Finish", callback_data = 'finish')])
			update.effective_message.reply_text("This is the preview of the buttons you just sent,",
			                                    reply_markup = InlineKeyboardMarkup(final_btns))
			return States.BTNS
			# return Posts.store_msg(update, context)
		except Exception as e:
			update.effective_message.reply_text(f"Invalid buttons, {e}"
			                                    f"\n\nSend it in this format,"
			                                    f"\nButton text 1 - http://www.example.com/ | Button text 2 - http://www.example2.com/"
			                                    f"\nButton text 3 - http://www.example3.com/")
		
	@staticmethod
	def store_msg(update, context):
		if not context.user_data.get('msg', 0):
			update.effective_message.reply_text("Send me the message you wanna broadcast,")
			return States.START
		if context.user_data.get('btns', 0):
			btn_mk = InlineKeyboardMarkup(context.user_data['btns'])
		else:
			btn_mk = None
		j = context.user_data['msg']
		prev_msg = send_appr_msg(bot = context.bot, to_chat_id = update.effective_user.id,
		                         parsing_mode = "HTML", msg = j,
		                         reply_mk = btn_mk)
		if str(type(prev_msg)).endswith("Promise'>"):
			prev_msg = prev_msg.result()
		update.effective_message.reply_text(text = "This is the preview of the message to be sent,", # as a reply to the brdcst msg
		                                    reply_markup = Users.get_confirm(),
		                                    reply_to_message_id = prev_msg.message_id)
		return States.CONFIRM
		
	@staticmethod
	def confirm_brdcst( update, context ):
		data = update.callback_query.data
		update.effective_message.delete()
		context.user_data['post'] = Post(message = context.user_data['msg'],
		                                 reply_markup = context.user_data.get('btns', 0),
		                                 channels = context.user_data['chnls'],
		                                 pin = True)
		if data == 'send':
			update.effective_message.reply_text(f"<b><u>POST DETAILS </u></b>"
			                                    f"\n"
			                                    f"\n⏰ <b>Scheduled at</b>: {context.user_data.get('schedule_at', 'Now')}"
			                                    f"\n{context.user_data['post']}"
			                                    f"\n<i> Do you want to broadcast the message with above setting? </i>",
			                                    parse_mode = 'HTML',
			                                    reply_markup = Users.yes_or_no())
			return States.FINAL
			# update.effective_message.reply_text("Do you want to pin this post?",
			#                                    reply_markup = Users.yes_or_no())
			# return States.PIN
		#  context = (context, msg)
		elif data in {'enqueue', 'schedule'}:
			update.callback_query.answer("Scheduling the broadcast...")
			update.effective_message.reply_text("Send the time of the broadcast in IST,"
			                                    "\nIf you wanna send it today, send only the name in 24h format - 14:20"
			                                    "\nAnyother day, include the date as well - 15-08-2020 17:55")
			return States.TIME
		else:
			update.callback_query.answer('Cancelled the broadcast')
		
		return Misc.help(update, context)
	
	@staticmethod
	def get_time(update: Update, context: CallbackContext):
		
		import pytz
		from datetime import datetime
		IST = pytz.timezone('Asia/Kolkata')
		try:
			input_time = update.effective_message.text.split(' ')
			if len(input_time) == 1:
				hour, minute = [int(i) for i in input_time[0].split(':')]
				schedule_at = datetime.now(IST).time().replace(hour = hour, minute = minute, second = 0)
				context.user_data['schedule_at'] = schedule_at
			elif len(input_time) == 2:
				day, mon, year = [int(i) for i in input_time[0].split('-')]
				hour, minute = [int(i) for i in input_time[1].split(':')]
				schedule_at = datetime.now(IST).replace(hour = hour, minute = minute, second = 0,
				                                        year = year, month = mon, day = day)
				context.user_data['schedule_at'] = schedule_at
			else:
				raise IndexError
		except (IndexError, ValueError):
			update.effective_message.reply_text("⚠ Follow the format.,"
			                                    "\nSend the time of the broadcast in IST,"
			                                    "\nIf you wanna send it today, send only the name in 24h format - 14:20"
			                                    "\nAnyother day, include the date as well - 15-08-2020 17:55")
		else:
			update.effective_message.reply_text(f"<b><u>POST DETAILS </u></b>"
			                                    f"\n"
			                                    f"\n⏰ <b>Scheduled at</b>: {context.user_data.get('schedule_at', 'Now')}"
			                                    f"\n{context.user_data['post']}"
			                                    f"\n<i> Do you want to broadcast the message with above setting? </i>",
			                                    parse_mode = 'HTML',
			                                    reply_markup = Users.yes_or_no())
			return States.FINAL
			# update.effective_message.reply_text("Do you want to pin this post?",
			#                                     reply_markup = Users.yes_or_no())
			# return States.PIN

	@staticmethod
	def get_pin_setting( update: Update, context: CallbackContext ):
		data = update.callback_query.data
		if data == 'no':
			update.effective_message.delete()
			context.user_data['post'].pin = False
		elif data == 'yes':
			update.effective_message.delete()
			context.user_data['post'].pin = True
		else:
			update.effective_message.reply_text("Invalid selection")
			return States.PIN
		update.effective_message.reply_text("💣 Do you want to enable self-destruct for this post?",
		                                    reply_markup = Users.yes_or_no())
		return States.DESTRUCT

	@staticmethod
	def get_self_destruct( update: Update, context: CallbackContext ):
		data = update.callback_query.data
		if data == 'no':
			update.effective_message.delete()
			update.effective_message.reply_text(f"<b><u>POST DETAILS </u></b>"
			                                    f"\n"
			                                    f"\n⏰ <b>Scheduled at</b>: {context.user_data.get('schedule_at', 'Now')}"
			                                    f"\n{context.user_data['post']}"
			                                    f"\n"
			                                    f"\n<i> Do you want to broadcast the message with above setting? </i>",
			                                    parse_mode = 'HTML',
			                                    reply_markup = Users.yes_or_no())
			return States.FINAL
		elif data == 'yes':
			update.effective_message.delete()
			update.effective_message.reply_text("How many hours/minutes I should destroy this post after sending?"
			                                    "\nFormat: 1hr (or) 60mins")
			return States.DESTRUCT_TIME
		else:
			update.effective_message.reply_text("Invalid selection")
			return States.DESTRUCT
	
	@staticmethod
	def get_self_destruct_time(update: Update, context: CallbackContext):
		try:
			update.effective_message.delete()
			input_time = update.effective_message.text
			if input_time.endswith('hrs') or input_time.endswith('hr'):
				time = int(input_time.strip('hrs')) * 60
			elif input_time.endswith('mins'):
				time = int(input_time.strip('mins'))
			else:
				raise IndexError
		except (IndexError, ValueError):
			update.effective_message.reply_text("⚠ Follow the format.,"
			                                    "\nSend the time in hour/mins after the broadcast to self-destruct,"
			                                    "\nFormat: 1hr (or) 60mins")
		else:
			context.user_data['post'].self_destruct = time
			update.effective_message.reply_text(f"<b><u>POST DETAILS </u></b>"
			                                    f"\n"
			                                    f"\n⏰ <b>Scheduled at</b>: {context.user_data.get('schedule_at', 'Now')}"
			                                    f"\n{context.user_data['post']}"
			                                    f"\n<i> Do you want to broadcast the message with above setting? </i>",
			                                    parse_mode = 'HTML',
			                                    reply_markup = Users.yes_or_no())
			return States.FINAL
		
	@staticmethod
	def get_confirm(update: Update, context: CallbackContext):
		data = update.callback_query.data
		if data == 'no':
			return Misc.help(update, context)
		else:
			job = context.job_queue.run_once(when = context.user_data.get('schedule_at', 5),
		                                   callback = send_appr_msg_job, context = context.user_data['post'],
		                                   name = f"{context.user_data.get('schedule_at', 5)}")
			update.effective_message.reply_text(f"Scheduled successfully to run at <pre>{job.job.next_run_time}</pre>",
		                                      parse_mode = 'HTML')
		return Misc.help(update, context)
