from telegram.ext import MessageHandler, CommandHandler, ConversationHandler, Filters, CallbackQueryHandler

from callbacks import Channels, Groups, Posts, Misc
from const import States, TG, Users


class Handlers:
	start = CommandHandler(['start', 'help'], Misc.help)
	add_group = ConversationHandler(
		entry_points = [CommandHandler('add_group', Groups.get_name, filters = Filters.chat(TG.ADMINS))],
		states = {
			1: [MessageHandler(Filters.text & ~Filters.command, Groups.create)]
		},
		fallbacks = []
	)
	list_group = CommandHandler('list', Groups.list, filters = Filters.chat(TG.ADMINS))
	remove_group = CommandHandler('remove_group', Groups.remove, filters = Filters.chat(TG.ADMINS))
	get_group = CallbackQueryHandler(Groups.get, pattern = "^grp_")
	rm_chnl = CallbackQueryHandler(Channels.remove, pattern = "^rm_chnl_")
	
	add_channel = ConversationHandler(
		entry_points = [CommandHandler('add_channel', Channels.add, filters = Filters.chat(TG.ADMINS))],
		states = {
			1: [MessageHandler(Filters.forwarded, Channels.add_2)],
			2: [CallbackQueryHandler(Channels.add_3, pattern = "^select_")]
		},
		fallbacks = []
	)
	
	broadcast = ConversationHandler(
		entry_points = [MessageHandler(Filters.regex('.*Broadcast$') & Filters.chat(TG.ADMINS),
		                               Posts.get_group),
		                CommandHandler('broadcast', Posts.get_group,
		                               filters = Filters.chat(TG.ADMINS))],
		states = {
			States.GROUP    : [CallbackQueryHandler(Posts.broadcast_strt, pattern = '^brd_grp'),
			                   CallbackQueryHandler(Misc.help, pattern = 'back')],
			States.START    : [MessageHandler(Filters.all & ~Filters.command, Posts.add_posts)],
			States.BTNS     :	[CallbackQueryHandler(Posts.inline_handler_for_btn_creation)],
			States.TXT      : [MessageHandler(Filters.text & ~Filters.command, Posts.get_text)],
			States.CONFIRM  : [CallbackQueryHandler(Posts.confirm_brdcst)],
			States.TIME     : [MessageHandler(Filters.text, Posts.get_time)],
			States.PIN      : [CallbackQueryHandler(Posts.get_pin_setting, pattern = '(yes)|(no)')],
			States.DESTRUCT : [CallbackQueryHandler(Posts.get_self_destruct, pattern = '(yes)|(no)')],
			States.DESTRUCT_TIME : [MessageHandler(Filters.text, Posts.get_self_destruct_time)],
			States.FINAL : [CallbackQueryHandler(Posts.get_confirm, pattern = '(yes)|(no)')]
		},
		fallbacks = [CommandHandler(['cancel', 'start', 'adminstart', 'adminmenu'], Misc.help)])
	
	# poll_hndlr = MessageHandler(Filters.poll, dummy)