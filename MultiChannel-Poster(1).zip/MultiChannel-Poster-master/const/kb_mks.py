from telegram import InlineKeyboardButton, InlineKeyboardMarkup


class Users:
	@staticmethod
	def get_confirm():
		return InlineKeyboardMarkup([[InlineKeyboardButton("🚀 Send now", callback_data = 'send'),
		                              InlineKeyboardButton("🕠 Enqueue", callback_data = "schedule")],
		                             [InlineKeyboardButton("🚮 Cancel", callback_data = 'cancel')]])
	
	@staticmethod
	def yes_or_no():
		return InlineKeyboardMarkup([
			[InlineKeyboardButton("✅", callback_data = "yes"),
			 InlineKeyboardButton("❌", callback_data = "no")]])
