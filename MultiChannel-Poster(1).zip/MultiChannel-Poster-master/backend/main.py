from pymongo import MongoClient

client = MongoClient()
db = client.channelads